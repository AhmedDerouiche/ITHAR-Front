function myFunction() {
    console.log(document.getElementById("type").value);
    if(document.getElementById("type").value== "Citoyen")
    
   {
    document.getElementById("type1").placeholder ="Nom & Prénom" ;

document.getElementById("nom").innerHTML="Nom & Prénom";
   }
   else{
   document.getElementById("type1").placeholder = "Nom de l'association";
   document.getElementById("nom").innerHTML="Nom de l'association";
   }
  }